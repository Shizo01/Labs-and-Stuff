# О программе
### Программа имеет 4 Activity. В первой Activity находятся 4 кнопки. По нажатии на первую кнопку открывается Activity2, в которой есть 8 кнопок. По нажатии на вторую кнопку открывается Activity3, в которой есть 6 кнопок. По нажатии на третью кнопку открывается Activity4, в которой есть одна кнопка с иконкой.
# Запуск программы
### Запустить виртуальное устройство. Выбрать приложение Laba2Mobile из списка приложений на устройстве.
# Демонстрация работы
### Первое Activity
![Activity1](https://github.com/user-attachments/assets/88a1c316-a402-4ffd-9117-2a9f56fc8d47)
### Второе Activity
![Activity2](https://github.com/user-attachments/assets/095e0f52-fffd-4e07-b53c-d90f69b73e4d)
### Третье Activity
![Activity3](https://github.com/user-attachments/assets/6f79551d-319e-4a8e-9f2b-0a638ca95b60)
### Четвертое Activity
![Activity4](https://github.com/user-attachments/assets/8552f1b1-ffd4-43d0-9907-60c832041b47)

